package com.ct7ct7ct7.androidvimeoplayer.listeners;

public interface VimeoPlayerTextTrackListener {
    void onTextTrackChanged(String kind, String label, String language);
}
