package com.ct7ct7ct7.androidvimeoplayer.listeners;

public interface VimeoPlayerVolumeListener {
    void onVolumeChanged(float volume);
}
