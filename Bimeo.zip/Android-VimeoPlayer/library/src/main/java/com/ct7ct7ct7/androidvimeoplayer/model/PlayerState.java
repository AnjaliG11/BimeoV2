package com.ct7ct7ct7.androidvimeoplayer.model;

public enum PlayerState {
    UNKNOWN, READY, ENDED, PLAYING, PAUSED
}
